Thank you for using iMonitor EAM - the advanced employees monitoring solution.
iMonitor EAM version 9.639

Date Updated: 2022-04-10

IMonitor EAM Installation:

First, extract all files from the ZIP archive which you can download from our official
website �C www.imonitorsoft.com. After extracting to specific folder, below two files would be
inside the folder.

1.EAMProTrial9.635.exe -- iMonitor EAM Console and Server program, compatible with all Windows 32bit/ 64bit
platforms, even latest Window 7/8/10/11. Please make sure install it on server computer of local
network.

2. AgentInstall.exe -- iMonitor EAM client program, compatible with all Windows 32bit/ 64bit
platforms, even latest Window 7/8/10/11.

3. imonitor-mac-agent.pkg -- iMonitor EAM client program for Mac OX, compatible with Mac OS version 10.8 and all newer versions.

4. imonitorlinux and ipprotect -- iMonitor EAM client program for Linux, compatible with Ubuntu and some other Linux system.

5. Readme.txt -- iMonitor EAM version changes and description.

About IMonitor EAM

IMonitor EAM is designed for business company customers, which can monitor and manage any
client computer inside local network. All real-time monitor activities will be fully in stealth mode
and take up much less cpu usage.
IMonitor EAM would be make customer feel full new experience. Easy use, clear catalogue,
detailed reports and quick starting have made IMonitor EAM take a good feedback from our
customers. Latest v9.31 not only enhance these customers favorite points also optimized
programs codes and add new feature which make program more stable and better compatibility.
For now, IMonitor EAM has taken a leading position in the aspect of client remote monitoring,
with IMonitor EAM, customers can fully control any client computer monitor activity and
remote assistant in the local network. Files managements like edit files, open files, download or
upload files, would be operated like window explorer. In the aspect of controlling internet and
applications access, IMonitor EAM can restrict remote computer's access to internet or
browsing specific websites, application access, instant message filter and window basic
command (e.g. shut down, restart, run program, open website). Besides above all, IMonitor
EAM provides a powerful remote computer hardware and software monitor function, any
alternation of client computer hardware and installed programs would be automatically
recorded. All easy features have made IMonitor EAM be more popular and no other choice for
business.

Currently IMonitor EAM will be satisfied with nearly all customers requirements, all activities
including below:

Email, instant message, keystrokes, FTP file transfer, websites visited, applications used, 
remote computer screen view, e-mail/web-mail, onlinestorage etc. For more details, please refer 
to features section or feel free to visit out official website �C www.imonitorsoft.com .

Besides above features, in latest v8.9, new feature of automaticlly backing up files and 
Muti-screen remote desktop live viewer have been added. Full details, please refer to 
changelog section.

IMonitor EAM Changelog:

What's new in version 9.639
Log and backup every screenshot created by screen capture tool.
Disable/enable mobile phone(iPhone and Android) which connected to computer via USB.

What's new in version 9.638
Log DingTalk chat conversations.

What's new in version 9.637
Encrypt file when file is sending out only.
Encrypt files with specific folders only.
File risks auto approve rules.

What's new in version 9.636
New algorithm to encrypt and decrypt files.
Block risky downloads with all browsers, effectively reduce the risk of computer viruses.

What's new in version 9.635
New Technical admin role, which can login EAM console to manage agents but can not view logs and screenshots. 
Enhanced U Disk White List.
New algorithm to list all installed software and log software changes.

What's new in version 9.634
Fixed small bugs in EAM console.
Allow user stop/start logs recording on their own.

What's new in version 9.633
Redirect blocked websites to blank page.
Chat logs for QQ new version.
Chat logs for Wechat new version.

What's new in version 9.632
Search in backed up files with keywords.
Document risks management and alert.
Real-time file backup logs.
Idle time and busy time chart control to show employee work status and the number of keystrokes per minute.
New file backup logic and algorithm.
Global file backup exclusions.

What's new in version 9.631
Fixed small bugs in EAM console.
More convenient and efficient way to browse logs

What's new in version 9.630
Fixed small bugs in EAM console.

What's new in version 9.629
Use the same user profile and database configuration files to manage multiple databases.
Fixed the mouse flickering problem on agent computer.
New agent installation option for Windows Terminal Server.

What's new in version 9.628
New application report to calculate user time.

What's new in version 9.627
Fix small bugs in EAM console.

What's new in version 9.626
Whitelist rule for application filter and website filter.
Hide offline agents in EAM Console program.
Multi-threaded logs upload.

What's new in version 9.625
Calculate Office software time.
Take a screenshot every time the log is generated.

What's new in version 9.624
Display computer name or IP address in agent list.
New network traffic algorithm.

What's new in version 9.624
Display computer name or IP address in agent list.
New network traffic algorithm.

What's new in version 9.623
Fixed network RDP connection issue in this version.

What's new in version 9.622
Added "Mass remove" and "Mass move to" function in agent list.

What's new in version 9.621
Fixed remote control bug on windows computer with dual monitors.
Small changes in encryption module.

What's new in version 9.620
New file transparent encryption module to prevent data loss and stop inner theft, this module is for EAM Encryption Edition only.

What's new in version 9.619
New file backup module.

What's new in version 9.618
Dynamic IP support on  EAM server.
New dashboards module.
New algorithm to calculate computer idle time.
Enhanced Current Activities module.
Fixed small bugs in old version.

What's new in version 9.617
New file security functions, block file transfer while user sending important file via web, mail, and chat applications.
Block file while user copy/move files to USB storage device.
Block new software installation.
Sort groups, computers, users by their names in the agent list. Keep the "Ungrouped agents" in the first position always.

What's new in version 9.616
Show current application and website of every agent in realtime.
Delete history text logs and screenshots automatically.
Bug fixed in Screenshots Viewer.

What's new in version 9.615
Fixed bug in report module for keystrokes logs.

What's new in version 9.614
Fixed bug in the agent installer program which can hang up the installation window.

What's new in version 9.613
New traffic calculation algorithm.
Do not encrypt screenshots.
Invalid screenshot detection.

What's new in version 9.612
Client automatic update function

What's new in version 9.61
New report module.
Allow user to delete history logs and screenshots manually.
File transfer monitoring and backup.
New Linux agent.

What's new in version 9.6
New database architecture.
Enhanced file backup function.
Fixed problem in old version.

What's new in version 9.5
New agent program for Linux.
Fixed problem to support latest Skype version.
Fixed problem of ending windows process.

What's new in version 9.4
New iMonitor EAM Lite Edition.

What's new in version 9.3
The EAM server supports Dynamic IP and Static IP address.
Fixed some small bugs in old version.

What's new in version 9.2
Export all text logs of an agent to EXCEL XLS file.
Play a WAV audio file when alerts received.
Camera light error was fixed.
New keyword detector program, more responsive and efficient.

What's new in version 9.1
Monitor employee activities in Remote Desktop sessions.
New user role based employee monitoring design and log viewer.

What's new in version 9.0
Send DOS commands, message, remote control commands to multiple agents with one click.
Send files to multiple agents with one click.
EAM server can use domain name as well as IP address.

What's new in version 8.9
Enhanced file backup feature, 10 archives will be stored on the server to keep file change history.
New screenshots viewer, user can double click the picture to view the screenshots with raw size. 
Fixed bugs in old version.

What's new in version 8.8
New Mac agent program allows to monitor all user activities with one installation with the root user.
New windows agent supports windows 10.
The version 8.8 windows agent program can scan the entire HDD and backup all important files by pre-set file extension names.
New outlook addin to capture incoming/outgoingemail emails per machine.

What's new in version 8.7
New agent program for Max OS X.
Supports Dynamic server IP address,agent program can detect server ip changes and keep connection to the server.

What's new in version 8.6
EAM 8.6 supports Multi-languages,including English, Chinese Simplified, Chinese Traditional, Spanish, Italian, French, Portuguese, Japanese, German, Korean.
Remote Camera and Live Camera function.
Unicode program and multilanguage logs reading.


What's new in version8.5
Capture screenshots when user print file, document or a picture.
New designed Screenshot Recorder of separate application, the logic is more simpler, but the function is more powerful.

What's new in version8.3
Live Desktop, View upto 30 remote live-desktops in one window at one time.
Automatically backup important file to EAM server when user eidt the file on client computer.
New designed user interface.

What's new in version 8.2
Allows user to stop/start monitoring on the client computer.
Records web comments posted.
Enhanced screenshots recorder is compatible with retina screen.
Fixed small bugs in previous version.

What's new in version 8.1
Fixed XP related bugs in old version
Some new designed user interface. 

What's new in version 8.0
Fixed bugs in old version
Japanese language added

What's new in version 7.9
Allows manager to seach agent list with a keyword
Japanese language added

What's new in version 7.8
New USB device monitoring function to record all USB device changes(Insert/Remove).

What's new in version 7.6
Enhanced reporting module.
New website logging feature supports all website browsers.


What's new in version 7.5
Record Skype text chat and Skype file transfers.
Record QQ text chat.
The new and more powerful reporting module for EAM Professional Edition.

What's new in version 7.2
More powerful remote installation tool.
Allow user to build MSI Installer to deploy EAM Agent program via Group Policy company-wide.
Fixed some small bugs in old version.
Automatically Add EAM applications into the exclusion list of Windows firewall.

What's new in version 7.1
Show both computer name and contact name at the first column.

What's new in version 7.0
Monitor more than 8 kind of online storage usage, record every detail of online storage use.

What's new in version 6.9
Monitor network traffic of every application which has network connections.
Allows to set traffic limits for application, and the program will block the connection if the traffic exceed the maximum.

What's new in version 6.8
Allows to set specific time limits of blocked website.
Allows to set daily time limits of blocked application.
Allows to add keywords and detect keyword in content such as keystrokes, window caption, website url, file, print job etc.
Take screenshot when keywork detected, you can also set to end the current application if the keyword appears.

What's new in version 6.7
Count computer idle time.
Count and analyze user's work time. count daily keystrokes, files, websites etc. 
Count how much time user spent on each application, count chat time, web time.

What's new in version 6.4

Screenshots can be stored on client computer or server computer.
Block 64 bits Applications.
Record website history with 64bits IE.

What is new in version v6.0

User can open remote camera to monitor employee behavior.
The version 6.0 can block HTTPS website.
The version 6.0 supports both VPN network and LAN.
The version 6.0 stores all all logs(include screenshots) on server database.
The version 6.0 can take screenshots of more than 10 kinds of commonly used application.
Further beautification program UI.

What is new in version v5.3


Powerful report dodule added in IMonitor EAM Professional edition, support more than 40 kinds of build-in reports, easy to export HTML format report from database with one click. 

Audit how much time employees spent time on each website.

Audit how much time employees spent on each application.


What is new in version v5.2


Add �� Search in database �� and �� Search in data list �� option.
Add Outlook addins integrated with EAM, which improve monitoring ability of Outlook
Received and Send Email, Outlook addin support some special protocol like Exchanger
Server.
Add new function, search logs via �� Locate logs by dates ��.
Add the feature, when computer is in idle time or screen saver being running, EAM will not
snap any screenshots.
Improve the logs search function, now users can view logs by date sort order.
Extend the trial time from 15 days to 30 days.
Fully support Window 64 bit OS, including Window XP 64 bit, Vista 64 bit and 7 64 bit.


What is new in version v5.0


Fully change over user interface, making EAM more easy to use.
Implement screenshot function; add time interval feature and screenshot default setting
is off.


What is new in version v4.90


Snapping remote computer screenshot all the time in fully stealth mode, customers can
view any specific time screenshot. Also customers can set the time interval of
screenshot.
Added System/User Activities feature which can log info like what time computer
started, shut down and sleep.
Added Keyword detecting function in Activity control which can automatically identify if
or not some sensitive or confidential words being typed.
WorkTime Tracker upgraded to 2.1
More codes being rewritten and optimized.
What's new in version v4.84
Records both destination file and source file when user copy file or move file.
Upgraded WorkTime Tracker to version 2.0.


What's new in version v4.83


Export all kind of detailed report with one click.
What's new in version v4.82
Supports view dual monitors in remote desktop viewer.


What's new in version v4.8


Allow manager to view summary report.
Monitor remote printer with unique IP address.


What's new in version v4.75


Allows user to set from date and to date to check relevant logs.
Allows user to disable alerts.
Allows user to change database directory and back database.
Deny anonymous access. User can't access Agent by installing another unregistered
EAM server, the connection will be denied (This feature is for Full Version Only).
Add user name to every log captured by the EAM Agent.
Fixed bugs in 4.74.


What's new in version 4.7


It stores important logs on centralized database on server computer, such as keystrokes,
mail logs, file logs, clipboard logs, website logs, ftp logs, print job logs, instant
message, etc. The Agent Program uploads collected logs to server computer
AUTOMATICALLY at interval of X minutes you specified. Click 'Agent Management->Log
synchronization' to change the value.


What's new in version 4.62


Allows manager to add new computer by its name as well as IP address. We recommend
to add computer by its IP address, because if the console and agent computer are in
different DOMAIN or WORKGROUP, the communication by computer name will be
unstable.


What's new in version 4.61


Allows manager to export typed keystrokes and instant messages to rich text format
report.
Fixed bugs in remote desktop viewer.


What's new in version 4.6


Allows manager to disable controversial logs such as keystrokes and web-based email,
and allows manager to create a time schedule to limit the monitoring duration.
Fixed the bug with nonstandard Microsoft Standard English (United States 101)
Keyboard.


What's new in version 4.5


Allows manager to remotely disable/lock USB stick, MMC/SD card, CD/DVD ROM on
employee's computer.


What's new in version 4.4


Fixed the bug with Exchange server (In old versions, after installing te agent on a
workstation outlook 2003 lost its connection with the exchange 2007 server ).


What's new in version 4.3


Add login help document.
Beautify console program user interface.


What's new in version 4.2


Log Tencent QQ/TM chat conversations.


What's new in version 4.1


Log outgoing webmail (Gmail, hotmail, yahoo mail).
Log AOL and ICQ chat conversations.


What's new in version 4.0


Support Windows Vista


What's new in version 3.8


Allows manager to see installed printers on remote computer.
Log all print jobs (Printer name, computer, user, document name, pages printed, copied
printed, etc). Allows manager to track printer's usage later.


What's new in version 3.7


Allows manager to see all shares include hidden shares on remote computer.
Allows manager to see which computer and user is accessing the shares of destination
computer.
Block IM software and webmail.


What's new in version 3.6


Log http file download.
Log searching phrase.
Supports 15 kinds of different character encoding.
Log clipboard data changing.
Allows manager to see all alarm logs of network computers.


What's new in version 3.5


Log file operations on employee's computer, such as copy, delete, create, rename, open,
copy to removable disk, etc.
Send an alarm to console program when employee do a file operation on removable
disk, add or remove a removable disk, Open an unwanted website, send or receive mail,
transfer file with FTP protocol, etc.


What's new in version 3.4


Allows manager to add firewall IPs/Ports blocking and passing rule and apply rules to
network computer.


What's new in version 3.3


Lock and unlock remote computer's ip address.
Allows manager to analyze employee's application using during working time.


What's new in version 3.2


Send command to log off current user, start screen saver and stop screen saver on
network computer.